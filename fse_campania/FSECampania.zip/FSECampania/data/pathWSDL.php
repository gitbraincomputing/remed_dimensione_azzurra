<?php

return array(
    'cancellazioneMetadati' => __DIR__.'\..\tracciati\CancellazioneMetadati\fseCancellazioneMetadati.wsdl',
    'comunicazioneConsensi' => __DIR__.'\..\tracciati\ComunicazioneConsensi\fseComunicazioneConsensi.wsdl',
    'comunicazioneMetadati' => __DIR__.'\..\tracciati\ComunicazioneMetadati\fseComunicazioneMetadati.wsdl',
    'esitoCaricamentoDocumento' => __DIR__.'\..\tracciati\EsitoCaricamento\fseEsitoCaricamentoDocumento.wsdl',
    'recuperoDocumento' => __DIR__.'\..\tracciati\RecuperoDocumento\fseRecuperoDocumento.wsdl',
    'recuperoInformativa' => __DIR__.'\..\tracciati\RecuperoInformativa\fseRecuperoInformativa.wsdl',
    'ricercaDocumenti' => __DIR__.'\..\tracciati\RicercaDocumenti\fseRicercaDocumenti.wsdl',
    'statoConsensi' => __DIR__.'\..\tracciati\StatoConsensi\fseStatoConsensi.wsdl'
);
