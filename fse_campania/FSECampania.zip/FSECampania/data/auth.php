<?php

return array(
    'username' => 'PROVAX00X00X000Y',
    'password' => 'Salve123',
    'identificativoOrganizzazione' => '150'
);